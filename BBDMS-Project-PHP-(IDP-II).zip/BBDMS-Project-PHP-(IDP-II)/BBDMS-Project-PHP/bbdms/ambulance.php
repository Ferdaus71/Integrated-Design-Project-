<?php
include('includes/config.php');

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $location = $_POST['location'];

    $sql = "INSERT INTO ambulance_requests (name, phone, location, status) VALUES (:name, :phone, :location, 1)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':name', $name, PDO::PARAM_STR);
    $query->bindParam(':phone', $phone, PDO::PARAM_STR);
    $query->bindParam(':location', $location, PDO::PARAM_STR);
    $query->execute();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Ambulance Service | BBDMS</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url('images/ambulance-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            font-family: Arial, sans-serif;
        }
        .container {
            background-color: rgba(0,0,0,0.7);
            border-radius: 10px;
            padding: 30px;
            margin-top: 50px;
        }
        h2, h3 {
            text-align: center;
            margin-bottom: 20px;
        }
        .card {
            background-color: rgba(255, 255, 255, 0.9);
            color: #333;
            border-radius: 8px;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #dc3545;
            border: none;
        }
        .btn-primary:hover {
            background-color: #c82333;
        }
        .navbar-brand span.bb {
            color: white;
            font-style: italic;
        }
        .navbar-brand span.dms {
            color: red;
            font-style: italic;
        }
    </style>
</head>
<body>

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php">
        <span class="bb">BB</span><span class="dms">DMS</span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="search.php">Search</a></li>
            <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
            <li class="nav-item"><a class="nav-link" href="ambulance.php">Ambulance</a></li>
            <li class="nav-item"><a class="nav-link" href="admin/">Login</a></li>
        </ul>
    </div>
</nav>

<!-- Content -->
<div class="container">
    <h2>🚑 Register for Ambulance Service</h2>
    <form method="post" class="mb-5">
        <div class="form-group">
            <label>Your Name</label>
            <input type="text" name="name" required class="form-control">
        </div>
        <div class="form-group">
            <label>Phone Number</label>
            <input type="text" name="phone" required class="form-control">
        </div>
        <div class="form-group">
            <label>Location</label>
            <textarea name="location" required class="form-control" rows="2"></textarea>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Register Ambulance</button>
    </form>

    <h3>🩺 Available Ambulances</h3>
    <div class="row">
        <?php
        $status = 1;
        $sql = "SELECT * FROM ambulance_requests WHERE status=:status ORDER BY reg_date DESC";
        $query = $dbh->prepare($sql);
        $query->bindParam(':status', $status, PDO::PARAM_INT);
        $query->execute();
        $results = $query->fetchAll(PDO::FETCH_OBJ);
        if ($query->rowCount() > 0) {
            foreach ($results as $row) {
                echo '<div class="col-md-4 mb-4">';
                echo '<div class="card p-3">';
                echo '<h5>' . htmlentities($row->name) . '</h5>';
                echo '<p><strong>Phone:</strong> ' . htmlentities($row->phone) . '</p>';
                echo '<p><strong>Location:</strong> ' . htmlentities($row->location) . '</p>';
                echo '</div></div>';
            }
        } else {
            echo "<p class='text-light'>No ambulance registrations available at the moment.</p>";
        }
        ?>
    </div>
</div>

<!-- Footer -->
<?php include('includes/footer.php'); ?>

<!-- Scripts -->
<script src="js/jquery-2.2.3.min.js"></script>
<script src="js/bootstrap.js"></script>

</body>
</html>
